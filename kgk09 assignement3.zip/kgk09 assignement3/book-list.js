const setEditModal = (id)=>{

    
    let c_name=document.getElementById("name-"+id.toString()).value;
    let c_profession=document.getElementById("prof-"+id.toString()).value;
    let c_mob_number=document.getElementById("mnum-"+id.toString()).value;
    let c_tel_number=document.getElementById("tnum-"+id.toString()).value;
   
    let data = {};

  

        data["id"]= id.toString();
        data["c_name"]= c_name;
        data["c_profession"]= c_profession;
        data["c_mob_number"]= c_mob_number;
        data["c_tel_number"]= c_tel_number;
        console.log(data);

    const xhttp = new XMLHttpRequest();
    xhttp.open("POST", "http://localhost:3000/contact/" + id.toString());
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send(JSON.stringify(data));
    location.reload();
}

    const deletecontact = (id) => {
    
        const xhttp = new XMLHttpRequest();
        xhttp.open("DELETE", "http://localhost:3000/contact/" + id.toString(), false);
        xhttp.send();
        location.reload();
    
    }
    


function loadcontacts() {
    const xhttp = new XMLHttpRequest();

    xhttp.open("GET", "http://localhost:3000/contact", false);
    xhttp.send();

    const contacts = JSON.parse(xhttp.responseText);
console.log(contacts);
    for (let contact of contacts) {
        let id  = contact.id.toString();    
        let x = `
            <div class="col-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">${contact.c_name}</h5>
                        <h6 class="card-subtitle mb-2 text-muted">${contact.id}</h6>

                        <div>Profession: ${contact.c_profession}</div>
			<div>Telephone number: ${contact.c_tel_number}</div>
                        <div>Mobile Number: ${contact.c_mob_number}</div>
                        <hr>
                        


                        <button type = "button" onclick = "deletecontact(${contact.id})" >Delete</button>
                        <button types="button" data-toggle="modal" data-target="#modifications-${contact.id}">
                            Edit
                        </button>
                        <div class="modal fade"
        id="modifications-${contact.id}" role="dialog">
        <div class="modal-dialog">
 
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
 
                    <h1 class="modal-title">
                        Edit Contact Information
                    </h1>
                </div>
 
                <div class="modal-body">
                     
                     
<p>
   

                <label for="name">Name:</label>         
                <input type="text" id="name-${contact.id}" name="name" value="${contact.c_name}"><br>
                <label for="prof">Profession:</label>
                <input type="text" id="prof-${contact.id}" name="prof" value="${contact.c_profession}"><br>
		<label for="tnum">Telephone Number:</label>
                <input type="text" id="tnum-${contact.id}" name="tnum" value="${contact.c_tel_number}"><br>
                <label for="mnum">Mobile Number:</label>
                <input type="text" id="mnum-${contact.id}" name="mnum" value="${contact.c_mob_number}"><br>
                
                    </p>
 
 
                </div>
 
                <div class="modal-footer">
                    <button type="button"
                        class="btn btn-primary"
                        onClick="setEditModal(${contact.id})">
                        Modify
                    </button>
                     
                    <button type="button"
                        class="btn btn-default"
                        data-dismiss="modal"
                        >
                        Close
                    </button>
                </div>
            </div>
        
               
            </div>
        `;

        document.getElementById('contacts').innerHTML = document.getElementById('contacts').innerHTML + x;
    }
}

loadcontacts();